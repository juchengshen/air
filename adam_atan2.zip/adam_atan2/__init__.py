from .adam_atan2_pytorch import AdamAtan2 as _AdamAtan2

# Export both spellings to be compatible with wrappers.
AdamAtan2 = _AdamAtan2
AdamATan2 = _AdamAtan2

__all__ = ["AdamAtan2", "AdamATan2"]