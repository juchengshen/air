from .adam_atan2 import AdamAtan2
from .adopt_atan2 import AdoptAtan2

try:
    from .muon_adam_atan2 import MuonAdamAtan2
except ModuleNotFoundError as exc:
    if exc.name != "einops":
        raise
    MuonAdamAtan2 = None

Adam = AdamAtan2
Adopt = AdoptAtan2
